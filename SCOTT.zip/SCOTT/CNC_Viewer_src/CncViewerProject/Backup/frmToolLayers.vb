Public Class frmToolLayers
    Private Sub tvTools_AfterCheck(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvTools.AfterCheck
        If e.Action = TreeViewAction.Unknown Then Return
        CType(e.Node.Tag, clsToolLayer).Hidden = Not e.Node.Checked
    End Sub

    Private Sub tvTools_BeforeSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles tvTools.BeforeSelect
        e.Cancel = True
    End Sub

    Private Sub btnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDone.Click
        Me.Close()
    End Sub
End Class