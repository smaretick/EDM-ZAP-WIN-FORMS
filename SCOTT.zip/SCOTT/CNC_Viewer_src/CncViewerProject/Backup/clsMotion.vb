
Friend Structure Address
    Dim Label As Char
    Dim Value As Single
    Dim StringValue As String
    Function Matches(ByVal a As Address) As Boolean
        Return (a.Label = Me.Label) And (a.Value = Me.Value)
    End Function
End Structure

Friend Class clsMotion
    Public Drills(9) As Address 'G81,G82
    Public ReturnLevel(1) As Address 'G98,G99
    Public DrillRapid As Address 'R
    Public Rapid As Address 'G00
    Public Linear As Address 'G01
    Public CCArc As Address 'G03
    Public CWArc As Address 'G02
    Public Inc As Address 'G91
    Public Abs As Address 'G90
    Public Plane(2) As Address 'G18,18,19
    Public Rotary As Address 'A B C
    Public SubCall As Address 'M98
    Public SubReturn As Address 'M99
End Class