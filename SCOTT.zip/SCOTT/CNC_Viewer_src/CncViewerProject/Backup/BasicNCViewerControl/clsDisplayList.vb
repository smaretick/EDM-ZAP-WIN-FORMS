Public Class clsDisplayList
    Public InView As Boolean = True
    Public Rapid As Boolean = True
    Public ParentIndex As Integer
    Public Color As Color
    Public Points() As PointF
End Class
