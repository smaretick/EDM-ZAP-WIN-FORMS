Public Class clsMotionRecord
    Public Codestring As String 'cnc codeline
    Public MotionType As Motion 'point,arc,line etc....
    Public Linenumber As Integer 'line number of CNC file
    Public Xold As Single
    Public Yold As Single
    Public Zold As Single
    Public Xpos As Single
    Public Ypos As Single
    Public Zpos As Single
    Public Rpoint As Single
    Public Rad As Single
    Public Sang As Single
    Public Eang As Single
    Public Xcentr As Single
    Public Ycentr As Single
    Public Zcentr As Single
    Public DrawClr As Color
    Public Tool As Single
    Public Speed As Single
    Public Feed As Single
    Public BeginProfile As Boolean
    Public Rotate As Boolean
    Public OldRotaryPos As Single
    Public NewRotaryPos As Single
    Public RotaryDir As Integer
    Public WrkPlane As Integer
    Public DrillClear As Single
    Public Inview As Boolean
End Class
