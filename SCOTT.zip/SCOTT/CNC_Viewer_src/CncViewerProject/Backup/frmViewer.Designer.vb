<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmViewer
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public CodeTip As System.Windows.Forms.ToolTip
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmViewer))
        Me.CodeTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.lblStatus = New System.Windows.Forms.ToolStripStatusLabel
        Me.Coordinates = New System.Windows.Forms.ToolStripStatusLabel
        Me.Progress = New System.Windows.Forms.ToolStripProgressBar
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.tsbOpen = New System.Windows.Forms.ToolStripButton
        Me.tscboMachines = New System.Windows.Forms.ToolStripComboBox
        Me.tsbDisplay = New System.Windows.Forms.ToolStripDropDownButton
        Me.mnuRapidLines = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuRapidPoints = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuAxisLines = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuAxisindicator = New System.Windows.Forms.ToolStripMenuItem
        Me.tsbToolsFilter = New System.Windows.Forms.ToolStripButton
        Me.tsbScreens = New System.Windows.Forms.ToolStripDropDownButton
        Me.mnuOneScreen = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuTwoScreens = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuFourScreens = New System.Windows.Forms.ToolStripMenuItem
        Me.tsbWebCheck = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.tsbPan = New System.Windows.Forms.ToolStripButton
        Me.tsbZoom = New System.Windows.Forms.ToolStripButton
        Me.tsbRotate = New System.Windows.Forms.ToolStripButton
        Me.tsbFence = New System.Windows.Forms.ToolStripButton
        Me.tsbFit = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.tsbView = New System.Windows.Forms.ToolStripDropDownButton
        Me.mnuTop = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuFront = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuRight = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuIsometric = New System.Windows.Forms.ToolStripMenuItem
        Me.tsbSelect = New System.Windows.Forms.ToolStripButton
        Me.tblScreens = New System.Windows.Forms.TableLayoutPanel
        Me.MG_Viewer4 = New MacGen.MG_BasicViewer
        Me.rmbView = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuFit = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuFence = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuPan = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuRotate = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuZoom = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuSelect = New System.Windows.Forms.ToolStripMenuItem
        Me.MG_Viewer3 = New MacGen.MG_BasicViewer
        Me.MG_Viewer2 = New MacGen.MG_BasicViewer
        Me.MG_Viewer1 = New MacGen.MG_BasicViewer
        Me.BreakPointSlider = New System.Windows.Forms.TrackBar
        Me.StatusStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.tblScreens.SuspendLayout()
        Me.rmbView.SuspendLayout()
        CType(Me.BreakPointSlider, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CodeTip
        '
        Me.CodeTip.AutoPopDelay = 3000
        Me.CodeTip.InitialDelay = 0
        Me.CodeTip.IsBalloon = True
        Me.CodeTip.OwnerDraw = True
        Me.CodeTip.ReshowDelay = 100
        Me.CodeTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.CodeTip.ToolTipTitle = "G-code source"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Title = "Open File"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatus, Me.Coordinates, Me.Progress})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 601)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(564, 22)
        Me.StatusStrip1.TabIndex = 4
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblStatus
        '
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(38, 17)
        Me.lblStatus.Text = "Ready"
        '
        'Coordinates
        '
        Me.Coordinates.Name = "Coordinates"
        Me.Coordinates.Size = New System.Drawing.Size(409, 17)
        Me.Coordinates.Spring = True
        Me.Coordinates.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Progress
        '
        Me.Progress.Name = "Progress"
        Me.Progress.Size = New System.Drawing.Size(100, 16)
        '
        'ToolStrip1
        '
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbOpen, Me.tscboMachines, Me.tsbDisplay, Me.tsbToolsFilter, Me.tsbScreens, Me.tsbWebCheck, Me.ToolStripSeparator1, Me.tsbPan, Me.tsbZoom, Me.tsbRotate, Me.tsbFence, Me.tsbFit, Me.ToolStripSeparator2, Me.tsbView, Me.tsbSelect})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(564, 25)
        Me.ToolStrip1.TabIndex = 5
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'tsbOpen
        '
        Me.tsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbOpen.Image = Global.MacGen.My.Resources.Resources.OpenFolder
        Me.tsbOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbOpen.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbOpen.Name = "tsbOpen"
        Me.tsbOpen.Size = New System.Drawing.Size(23, 22)
        Me.tsbOpen.Text = "Open"
        '
        'tscboMachines
        '
        Me.tscboMachines.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.tscboMachines.Name = "tscboMachines"
        Me.tscboMachines.Padding = New System.Windows.Forms.Padding(1)
        Me.tscboMachines.Size = New System.Drawing.Size(75, 25)
        '
        'tsbDisplay
        '
        Me.tsbDisplay.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbDisplay.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuRapidLines, Me.mnuRapidPoints, Me.mnuAxisLines, Me.mnuAxisindicator})
        Me.tsbDisplay.Image = Global.MacGen.My.Resources.Resources.DisplayOpts
        Me.tsbDisplay.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbDisplay.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbDisplay.Name = "tsbDisplay"
        Me.tsbDisplay.Size = New System.Drawing.Size(29, 22)
        Me.tsbDisplay.Text = "&Display"
        '
        'mnuRapidLines
        '
        Me.mnuRapidLines.Checked = True
        Me.mnuRapidLines.CheckOnClick = True
        Me.mnuRapidLines.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuRapidLines.Name = "mnuRapidLines"
        Me.mnuRapidLines.Size = New System.Drawing.Size(151, 22)
        Me.mnuRapidLines.Text = "Rapid &Lines"
        '
        'mnuRapidPoints
        '
        Me.mnuRapidPoints.Checked = True
        Me.mnuRapidPoints.CheckOnClick = True
        Me.mnuRapidPoints.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuRapidPoints.Name = "mnuRapidPoints"
        Me.mnuRapidPoints.Size = New System.Drawing.Size(151, 22)
        Me.mnuRapidPoints.Text = "Rapid &Points"
        '
        'mnuAxisLines
        '
        Me.mnuAxisLines.Checked = True
        Me.mnuAxisLines.CheckOnClick = True
        Me.mnuAxisLines.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuAxisLines.Name = "mnuAxisLines"
        Me.mnuAxisLines.Size = New System.Drawing.Size(151, 22)
        Me.mnuAxisLines.Text = "&Axis Lines"
        '
        'mnuAxisindicator
        '
        Me.mnuAxisindicator.Checked = True
        Me.mnuAxisindicator.CheckOnClick = True
        Me.mnuAxisindicator.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuAxisindicator.Name = "mnuAxisindicator"
        Me.mnuAxisindicator.Size = New System.Drawing.Size(151, 22)
        Me.mnuAxisindicator.Text = "Axis &Indicator"
        '
        'tsbToolsFilter
        '
        Me.tsbToolsFilter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbToolsFilter.Image = Global.MacGen.My.Resources.Resources.ToolLayers
        Me.tsbToolsFilter.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbToolsFilter.Name = "tsbToolsFilter"
        Me.tsbToolsFilter.Size = New System.Drawing.Size(23, 22)
        Me.tsbToolsFilter.Text = "Tool Layers"
        '
        'tsbScreens
        '
        Me.tsbScreens.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbScreens.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuOneScreen, Me.mnuTwoScreens, Me.mnuFourScreens})
        Me.tsbScreens.Image = Global.MacGen.My.Resources.Resources.Screens4
        Me.tsbScreens.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbScreens.Name = "tsbScreens"
        Me.tsbScreens.Size = New System.Drawing.Size(29, 22)
        Me.tsbScreens.Text = "Screens"
        '
        'mnuOneScreen
        '
        Me.mnuOneScreen.Image = Global.MacGen.My.Resources.Resources.Screen1
        Me.mnuOneScreen.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnuOneScreen.Name = "mnuOneScreen"
        Me.mnuOneScreen.Size = New System.Drawing.Size(116, 22)
        Me.mnuOneScreen.Tag = "1"
        Me.mnuOneScreen.Text = "&1 One"
        '
        'mnuTwoScreens
        '
        Me.mnuTwoScreens.Image = Global.MacGen.My.Resources.Resources.Screens2
        Me.mnuTwoScreens.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnuTwoScreens.Name = "mnuTwoScreens"
        Me.mnuTwoScreens.Size = New System.Drawing.Size(116, 22)
        Me.mnuTwoScreens.Tag = "2"
        Me.mnuTwoScreens.Text = "&2 Two"
        '
        'mnuFourScreens
        '
        Me.mnuFourScreens.Image = Global.MacGen.My.Resources.Resources.Screens4
        Me.mnuFourScreens.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnuFourScreens.Name = "mnuFourScreens"
        Me.mnuFourScreens.Size = New System.Drawing.Size(116, 22)
        Me.mnuFourScreens.Tag = "4"
        Me.mnuFourScreens.Text = "&4 Four"
        '
        'tsbWebCheck
        '
        Me.tsbWebCheck.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsbWebCheck.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbWebCheck.Image = Global.MacGen.My.Resources.Resources.Web
        Me.tsbWebCheck.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbWebCheck.Name = "tsbWebCheck"
        Me.tsbWebCheck.Size = New System.Drawing.Size(23, 22)
        Me.tsbWebCheck.Text = "Phone Home"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'tsbPan
        '
        Me.tsbPan.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsbPan.CheckOnClick = True
        Me.tsbPan.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbPan.Image = Global.MacGen.My.Resources.Resources.ViewPan
        Me.tsbPan.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbPan.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbPan.Name = "tsbPan"
        Me.tsbPan.Size = New System.Drawing.Size(23, 22)
        Me.tsbPan.Tag = "Pan"
        Me.tsbPan.Text = "Pan"
        '
        'tsbZoom
        '
        Me.tsbZoom.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsbZoom.CheckOnClick = True
        Me.tsbZoom.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbZoom.Image = Global.MacGen.My.Resources.Resources.ViewZoom
        Me.tsbZoom.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbZoom.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbZoom.Name = "tsbZoom"
        Me.tsbZoom.Size = New System.Drawing.Size(23, 22)
        Me.tsbZoom.Tag = "Zoom"
        Me.tsbZoom.Text = "Zoom"
        '
        'tsbRotate
        '
        Me.tsbRotate.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsbRotate.CheckOnClick = True
        Me.tsbRotate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbRotate.Image = Global.MacGen.My.Resources.Resources.ViewRotate
        Me.tsbRotate.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbRotate.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbRotate.Name = "tsbRotate"
        Me.tsbRotate.Size = New System.Drawing.Size(23, 22)
        Me.tsbRotate.Tag = "Rotate"
        Me.tsbRotate.Text = "Rotate"
        '
        'tsbFence
        '
        Me.tsbFence.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsbFence.CheckOnClick = True
        Me.tsbFence.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbFence.Image = Global.MacGen.My.Resources.Resources.ViewFence
        Me.tsbFence.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbFence.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbFence.Name = "tsbFence"
        Me.tsbFence.Size = New System.Drawing.Size(23, 22)
        Me.tsbFence.Tag = "Fence"
        Me.tsbFence.Text = "Fence"
        '
        'tsbFit
        '
        Me.tsbFit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsbFit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbFit.Image = Global.MacGen.My.Resources.Resources.ViewFit
        Me.tsbFit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbFit.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbFit.Name = "tsbFit"
        Me.tsbFit.Size = New System.Drawing.Size(23, 22)
        Me.tsbFit.Tag = "Fit"
        Me.tsbFit.Text = "Fit"
        Me.tsbFit.ToolTipText = "View Fit [Shift + Click All Views]"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'tsbView
        '
        Me.tsbView.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsbView.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbView.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuTop, Me.mnuFront, Me.mnuRight, Me.mnuIsometric})
        Me.tsbView.Image = CType(resources.GetObject("tsbView.Image"), System.Drawing.Image)
        Me.tsbView.ImageTransparentColor = System.Drawing.Color.Fuchsia
        Me.tsbView.Name = "tsbView"
        Me.tsbView.Size = New System.Drawing.Size(29, 22)
        Me.tsbView.Text = "&View"
        '
        'mnuTop
        '
        Me.mnuTop.Image = CType(resources.GetObject("mnuTop.Image"), System.Drawing.Image)
        Me.mnuTop.ImageTransparentColor = System.Drawing.Color.Fuchsia
        Me.mnuTop.Name = "mnuTop"
        Me.mnuTop.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.mnuTop.Size = New System.Drawing.Size(165, 22)
        Me.mnuTop.Tag = "Top"
        Me.mnuTop.Text = "&Top"
        '
        'mnuFront
        '
        Me.mnuFront.Image = CType(resources.GetObject("mnuFront.Image"), System.Drawing.Image)
        Me.mnuFront.ImageTransparentColor = System.Drawing.Color.Fuchsia
        Me.mnuFront.Name = "mnuFront"
        Me.mnuFront.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.mnuFront.Size = New System.Drawing.Size(165, 22)
        Me.mnuFront.Tag = "Front"
        Me.mnuFront.Text = "&Front"
        '
        'mnuRight
        '
        Me.mnuRight.Image = CType(resources.GetObject("mnuRight.Image"), System.Drawing.Image)
        Me.mnuRight.ImageTransparentColor = System.Drawing.Color.Fuchsia
        Me.mnuRight.Name = "mnuRight"
        Me.mnuRight.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.mnuRight.Size = New System.Drawing.Size(165, 22)
        Me.mnuRight.Tag = "Right"
        Me.mnuRight.Text = "&Right"
        '
        'mnuIsometric
        '
        Me.mnuIsometric.Image = CType(resources.GetObject("mnuIsometric.Image"), System.Drawing.Image)
        Me.mnuIsometric.ImageTransparentColor = System.Drawing.Color.Fuchsia
        Me.mnuIsometric.Name = "mnuIsometric"
        Me.mnuIsometric.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.mnuIsometric.Size = New System.Drawing.Size(165, 22)
        Me.mnuIsometric.Tag = "ISO"
        Me.mnuIsometric.Text = "&Isometric"
        '
        'tsbSelect
        '
        Me.tsbSelect.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsbSelect.Checked = True
        Me.tsbSelect.CheckOnClick = True
        Me.tsbSelect.CheckState = System.Windows.Forms.CheckState.Checked
        Me.tsbSelect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbSelect.Image = CType(resources.GetObject("tsbSelect.Image"), System.Drawing.Image)
        Me.tsbSelect.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbSelect.Name = "tsbSelect"
        Me.tsbSelect.Size = New System.Drawing.Size(23, 22)
        Me.tsbSelect.Tag = "Select"
        Me.tsbSelect.Text = "Select"
        '
        'tblScreens
        '
        Me.tblScreens.BackColor = System.Drawing.Color.Black
        Me.tblScreens.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.tblScreens.ColumnCount = 2
        Me.tblScreens.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tblScreens.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tblScreens.Controls.Add(Me.MG_Viewer4, 1, 1)
        Me.tblScreens.Controls.Add(Me.MG_Viewer3, 0, 1)
        Me.tblScreens.Controls.Add(Me.MG_Viewer2, 1, 0)
        Me.tblScreens.Controls.Add(Me.MG_Viewer1, 0, 0)
        Me.tblScreens.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tblScreens.Location = New System.Drawing.Point(0, 25)
        Me.tblScreens.Margin = New System.Windows.Forms.Padding(0)
        Me.tblScreens.Name = "tblScreens"
        Me.tblScreens.RowCount = 2
        Me.tblScreens.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tblScreens.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tblScreens.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tblScreens.Size = New System.Drawing.Size(564, 531)
        Me.tblScreens.TabIndex = 6
        '
        'MG_Viewer4
        '
        Me.MG_Viewer4.ArcAxis = MacGen.Axis.Z
        Me.MG_Viewer4.AxisIndicatorScale = 0.75!
        Me.MG_Viewer4.BackColor = System.Drawing.Color.Black
        Me.MG_Viewer4.BreakPoint = -1
        Me.MG_Viewer4.ContextMenuStrip = Me.rmbView
        Me.MG_Viewer4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MG_Viewer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MG_Viewer4.DynamicViewManipulation = True
        Me.MG_Viewer4.FourthAxis = 0.0!
        Me.MG_Viewer4.Location = New System.Drawing.Point(282, 266)
        Me.MG_Viewer4.Margin = New System.Windows.Forms.Padding(0)
        Me.MG_Viewer4.Name = "MG_Viewer4"
        Me.MG_Viewer4.Pitch = 0.0!
        Me.MG_Viewer4.Roll = 0.0!
        Me.MG_Viewer4.RotaryDirection = MacGen.RotaryDirection.CW
        Me.MG_Viewer4.RotaryPlane = MacGen.Axis.X
        Me.MG_Viewer4.RotaryType = MacGen.RotaryMotionType.BMC
        Me.MG_Viewer4.Size = New System.Drawing.Size(281, 264)
        Me.MG_Viewer4.TabIndex = 3
        Me.MG_Viewer4.ViewManipMode = MacGen.MG_BasicViewer.ManipMode.SELECTION
        Me.MG_Viewer4.Yaw = 0.0!
        '
        'rmbView
        '
        Me.rmbView.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFit, Me.mnuFence, Me.mnuPan, Me.mnuRotate, Me.mnuZoom, Me.mnuSelect})
        Me.rmbView.Name = "rmbView"
        Me.rmbView.Size = New System.Drawing.Size(119, 136)
        '
        'mnuFit
        '
        Me.mnuFit.Image = Global.MacGen.My.Resources.Resources.ViewFit
        Me.mnuFit.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnuFit.Name = "mnuFit"
        Me.mnuFit.Size = New System.Drawing.Size(118, 22)
        Me.mnuFit.Tag = "Fit"
        Me.mnuFit.Text = "Fit"
        '
        'mnuFence
        '
        Me.mnuFence.Image = Global.MacGen.My.Resources.Resources.ViewFence
        Me.mnuFence.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnuFence.Name = "mnuFence"
        Me.mnuFence.Size = New System.Drawing.Size(118, 22)
        Me.mnuFence.Tag = "Fence"
        Me.mnuFence.Text = "Fence"
        '
        'mnuPan
        '
        Me.mnuPan.Image = Global.MacGen.My.Resources.Resources.ViewPan
        Me.mnuPan.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnuPan.Name = "mnuPan"
        Me.mnuPan.Size = New System.Drawing.Size(118, 22)
        Me.mnuPan.Tag = "Pan"
        Me.mnuPan.Text = "Pan"
        '
        'mnuRotate
        '
        Me.mnuRotate.Image = Global.MacGen.My.Resources.Resources.ViewRotate
        Me.mnuRotate.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnuRotate.Name = "mnuRotate"
        Me.mnuRotate.Size = New System.Drawing.Size(118, 22)
        Me.mnuRotate.Tag = "Rotate"
        Me.mnuRotate.Text = "Rotate"
        '
        'mnuZoom
        '
        Me.mnuZoom.Image = Global.MacGen.My.Resources.Resources.ViewZoom
        Me.mnuZoom.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnuZoom.Name = "mnuZoom"
        Me.mnuZoom.Size = New System.Drawing.Size(118, 22)
        Me.mnuZoom.Tag = "Zoom"
        Me.mnuZoom.Text = "Zoom"
        '
        'mnuSelect
        '
        Me.mnuSelect.Image = Global.MacGen.My.Resources.Resources._Select
        Me.mnuSelect.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnuSelect.Name = "mnuSelect"
        Me.mnuSelect.Size = New System.Drawing.Size(118, 22)
        Me.mnuSelect.Tag = "Select"
        Me.mnuSelect.Text = "Select"
        '
        'MG_Viewer3
        '
        Me.MG_Viewer3.ArcAxis = MacGen.Axis.Z
        Me.MG_Viewer3.AxisIndicatorScale = 0.75!
        Me.MG_Viewer3.BackColor = System.Drawing.Color.Black
        Me.MG_Viewer3.BreakPoint = -1
        Me.MG_Viewer3.ContextMenuStrip = Me.rmbView
        Me.MG_Viewer3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MG_Viewer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MG_Viewer3.DynamicViewManipulation = True
        Me.MG_Viewer3.FourthAxis = 0.0!
        Me.MG_Viewer3.Location = New System.Drawing.Point(1, 266)
        Me.MG_Viewer3.Margin = New System.Windows.Forms.Padding(0)
        Me.MG_Viewer3.Name = "MG_Viewer3"
        Me.MG_Viewer3.Pitch = 0.0!
        Me.MG_Viewer3.Roll = 0.0!
        Me.MG_Viewer3.RotaryDirection = MacGen.RotaryDirection.CW
        Me.MG_Viewer3.RotaryPlane = MacGen.Axis.X
        Me.MG_Viewer3.RotaryType = MacGen.RotaryMotionType.BMC
        Me.MG_Viewer3.Size = New System.Drawing.Size(280, 264)
        Me.MG_Viewer3.TabIndex = 2
        Me.MG_Viewer3.ViewManipMode = MacGen.MG_BasicViewer.ManipMode.SELECTION
        Me.MG_Viewer3.Yaw = 0.0!
        '
        'MG_Viewer2
        '
        Me.MG_Viewer2.ArcAxis = MacGen.Axis.Z
        Me.MG_Viewer2.AxisIndicatorScale = 0.75!
        Me.MG_Viewer2.BackColor = System.Drawing.Color.Black
        Me.MG_Viewer2.BreakPoint = -1
        Me.MG_Viewer2.ContextMenuStrip = Me.rmbView
        Me.MG_Viewer2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MG_Viewer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MG_Viewer2.DynamicViewManipulation = True
        Me.MG_Viewer2.FourthAxis = 0.0!
        Me.MG_Viewer2.Location = New System.Drawing.Point(282, 1)
        Me.MG_Viewer2.Margin = New System.Windows.Forms.Padding(0)
        Me.MG_Viewer2.Name = "MG_Viewer2"
        Me.MG_Viewer2.Pitch = 0.0!
        Me.MG_Viewer2.Roll = 0.0!
        Me.MG_Viewer2.RotaryDirection = MacGen.RotaryDirection.CW
        Me.MG_Viewer2.RotaryPlane = MacGen.Axis.X
        Me.MG_Viewer2.RotaryType = MacGen.RotaryMotionType.BMC
        Me.MG_Viewer2.Size = New System.Drawing.Size(281, 264)
        Me.MG_Viewer2.TabIndex = 1
        Me.MG_Viewer2.ViewManipMode = MacGen.MG_BasicViewer.ManipMode.SELECTION
        Me.MG_Viewer2.Yaw = 0.0!
        '
        'MG_Viewer1
        '
        Me.MG_Viewer1.ArcAxis = MacGen.Axis.Z
        Me.MG_Viewer1.AxisIndicatorScale = 0.75!
        Me.MG_Viewer1.BackColor = System.Drawing.Color.Black
        Me.MG_Viewer1.BreakPoint = -1
        Me.MG_Viewer1.ContextMenuStrip = Me.rmbView
        Me.MG_Viewer1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MG_Viewer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MG_Viewer1.DynamicViewManipulation = True
        Me.MG_Viewer1.FourthAxis = 0.0!
        Me.MG_Viewer1.Location = New System.Drawing.Point(1, 1)
        Me.MG_Viewer1.Margin = New System.Windows.Forms.Padding(0)
        Me.MG_Viewer1.Name = "MG_Viewer1"
        Me.MG_Viewer1.Pitch = 0.0!
        Me.MG_Viewer1.Roll = 0.0!
        Me.MG_Viewer1.RotaryDirection = MacGen.RotaryDirection.CW
        Me.MG_Viewer1.RotaryPlane = MacGen.Axis.X
        Me.MG_Viewer1.RotaryType = MacGen.RotaryMotionType.BMC
        Me.MG_Viewer1.Size = New System.Drawing.Size(280, 264)
        Me.MG_Viewer1.TabIndex = 0
        Me.MG_Viewer1.ViewManipMode = MacGen.MG_BasicViewer.ManipMode.SELECTION
        Me.MG_Viewer1.Yaw = 0.0!
        '
        'BreakPointSlider
        '
        Me.BreakPointSlider.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BreakPointSlider.Location = New System.Drawing.Point(0, 556)
        Me.BreakPointSlider.Margin = New System.Windows.Forms.Padding(0)
        Me.BreakPointSlider.Name = "BreakPointSlider"
        Me.BreakPointSlider.Size = New System.Drawing.Size(564, 45)
        Me.BreakPointSlider.TabIndex = 7
        Me.BreakPointSlider.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'frmViewer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(564, 623)
        Me.Controls.Add(Me.tblScreens)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.BreakPointSlider)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.ForeColor = System.Drawing.SystemColors.WindowText
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(68, 66)
        Me.MinimumSize = New System.Drawing.Size(425, 225)
        Me.Name = "frmViewer"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Tag = ""
        Me.Text = "BASIC 3-D Viewer [NOT FOR PRODUCTION USE!]"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.tblScreens.ResumeLayout(False)
        Me.rmbView.ResumeLayout(False)
        CType(Me.BreakPointSlider, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents lblStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Coordinates As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Progress As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents tsbOpen As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbView As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents mnuTop As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFront As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuRight As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuIsometric As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsbDisplay As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents mnuRapidLines As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuRapidPoints As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAxisLines As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAxisindicator As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsbFit As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbFence As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbPan As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbRotate As System.Windows.Forms.ToolStripButton
    Friend WithEvents tblScreens As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents tsbScreens As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents mnuOneScreen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTwoScreens As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFourScreens As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MG_Viewer4 As MacGen.MG_BasicViewer
    Friend WithEvents MG_Viewer3 As MacGen.MG_BasicViewer
    Friend WithEvents MG_Viewer2 As MacGen.MG_BasicViewer
    Friend WithEvents MG_Viewer1 As MacGen.MG_BasicViewer
    Friend WithEvents tsbZoom As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbSelect As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbToolsFilter As System.Windows.Forms.ToolStripButton
    Friend WithEvents tscboMachines As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents rmbView As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuFit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFence As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPan As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuRotate As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuZoom As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSelect As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BreakPointSlider As System.Windows.Forms.TrackBar
    Friend WithEvents tsbWebCheck As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
#End Region
End Class