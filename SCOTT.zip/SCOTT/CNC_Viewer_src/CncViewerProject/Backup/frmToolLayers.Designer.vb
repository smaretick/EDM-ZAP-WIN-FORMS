<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmToolLayers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tvTools = New System.Windows.Forms.TreeView
        Me.btnDone = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'tvTools
        '
        Me.tvTools.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tvTools.CheckBoxes = True
        Me.tvTools.Location = New System.Drawing.Point(0, 0)
        Me.tvTools.Name = "tvTools"
        Me.tvTools.ShowLines = False
        Me.tvTools.ShowPlusMinus = False
        Me.tvTools.ShowRootLines = False
        Me.tvTools.Size = New System.Drawing.Size(102, 166)
        Me.tvTools.TabIndex = 0
        '
        'btnDone
        '
        Me.btnDone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDone.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnDone.Location = New System.Drawing.Point(21, 172)
        Me.btnDone.Name = "btnDone"
        Me.btnDone.Size = New System.Drawing.Size(61, 26)
        Me.btnDone.TabIndex = 1
        Me.btnDone.Text = "Done"
        Me.btnDone.UseVisualStyleBackColor = True
        '
        'frmToolLayers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnDone
        Me.ClientSize = New System.Drawing.Size(102, 199)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnDone)
        Me.Controls.Add(Me.tvTools)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmToolLayers"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tvTools As System.Windows.Forms.TreeView
    Friend WithEvents btnDone As System.Windows.Forms.Button
End Class
