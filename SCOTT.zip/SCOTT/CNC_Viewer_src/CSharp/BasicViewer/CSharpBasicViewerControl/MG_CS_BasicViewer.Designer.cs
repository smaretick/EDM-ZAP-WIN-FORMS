﻿namespace MacGen
{
    partial class MG_CS_BasicViewer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

    
        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // MG_CS_BasicViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "MG_CS_BasicViewer";
            this.Size = new System.Drawing.Size(210, 211);
            this.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.MG_BasicViewer_MouseWheel);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.MG_BasicViewer_Paint);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MG_BasicViewer_MouseMove);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MG_BasicViewer_MouseDown);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MG_BasicViewer_MouseUp);
            this.SizeChanged += new System.EventHandler(this.MG_CS_BasicViewer_SizeChanged);
            this.ResumeLayout(false);

        }

        #endregion
    }
}
